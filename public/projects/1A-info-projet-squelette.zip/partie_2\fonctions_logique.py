# cette bibliothèque contient les fonctions logiques du projet
# elle est utilisée par la partie 1 (console) et la partie 2 (FreeCAD)

from types_projet import *
from constantes import *

import random

# genere une grille aleatoire
# @param densite de murs en pourcentage (entier entre 0 et 100)
# @return grille : une liste de liste contenant soit des 0 (mur) soit des 1 (vide)
def generer_grille(densite):
	x = 0
	x = 0
	grille = [[1 for i in range(TAILLE)]for i in range(TAILLE)]
	dens_compteur = 0
	while dens_compteur < densite:
		x = random.randint(0,9)
		y = random.randint(0,9)
		if grille[x][y] == 1:
			grille[x][y] = 0
			dens_compteur += 1
	return grille


	
# verifie si une coordonnée (x ou y) est valide
# valide = entier entre 0 et TAILLE-1
# @param c : la coordonnée (x ou y)
# @return booléen : vrai si valide, faux sinon
def coord_valide(c):

	# à faire : écrire le corps de cette fonction
	pass
	
	
# verifie si une position est valide
# valide = les coordonnées x et y sont valides, et la position n'est pas un mur
# @param x : la coordonnée x de la position
# @param y : la coordonnée y de la position
# @return booléen : vrai si valide, faux sinon
def position_valide(x, y, grille):
	
	# à faire : écrire le corps de cette fonction
	pass
	
	

# calcule les distances dans la grille entre start et target 
# (1ère passe de l'algorithme de Dijsktra adapté aux matrices)
# @param la grille
# @param depart : position de départ (Pos)
# @param arrivée : position d'arrivée (Pos)
# @return chemin_existe : un booléen, vrai si le point d'arrivée a été atteint, 0 sinon
# @return distances : une liste de liste contenant un entier (la distance au point de départ) pour chaque position calculée, ou -1 si la position n'a pas de distance (mur ou position non calculée)
def calcul_distances(grille, depart, arrivee):
	dist = [[-1 for k in range(10)] for i in range(10)]
	D_x, D_y = depart[0], depart[1]
	dist[D_x][D_y] = 0
	LAT = [depart]
	if grille[D_x][D_y] == 0:
		return False, dist
	while len(LAT) != 0 :
		C = LAT.pop(0)
		C_x, C_y = C[0], C[1]
		V = voisin(C)
		for v in V:
			v_x, v_y = v[0], v[1]
			if v_x == arrivee[0] and v_y == arrivee[1] and grille[v_x][v_y] != 0:
				dist[v_x][v_y] = dist[C_x][C_y] + 1
				return True, dist
			elif grille[v_x][v_y] != 0 and dist[v_x][v_y] == -1:
				dist[v_x][v_y] = dist[C_x][C_y] + 1
				LAT.append(v)
	return False, dist



def voisin(pos):
	D = [(0, 1), (0, -1), (1, 0), (-1, 0)]
	V = []
	for d in D:
		u_x, u_y = pos[0] + d[0], pos[1] + d[1]
		if 0<=u_x<=9 and 0<=u_y<=9:
			V.append((u_x,u_y))
	return V

# renvoie un plus court chemin dans la grille en fonction des distances
# note: un chemin DOIT exister
# (2ème passe de l'algorithme de Dijsktra adapté aux matrices)
# @param distances : la grille des distances, telle que fournie par calcul_distances
# @param depart : position de départ (Pos)
# @param arrivée : position d'arrivée (Pos)
# @return chemin : une liste de positions (Pos) composant le chemin

# ~ def calcul_chemin(dist, depart, arrivee):
	# ~ C = arrivee
	# ~ chemin = []
	# ~ while True:
		# ~ V = voisin(C)
		# ~ C_x, C_y = C[0], C[1]
		# ~ for v in V:
			# ~ v_x, v_y = v[0], v[1]
			# ~ if v_x == depart[0] and v_y == depart[1]:
				# ~ return chemin
			# ~ elif dist[v_x][v_y] == dist[C_x][C_y]-1:
				# ~ prochain = v
			# ~ chemin.append(prochain)
			# ~ C = prochain
	# ~ return chemin

def calcul_chemin(dist, depart, arrivee):
    C = arrivee
    chemin = [C]
    while C != depart:
        V = voisin(C)
        C_x, C_y = C[0], C[1]
        prochain = None  # initialisation
        for v in V:
            v_x, v_y = v[0], v[1]
            if dist[v_x][v_y] == dist[C_x][C_y] - 1:
                prochain = v
                break  # on prend le premier qu’on trouve
        if prochain is None:
            raise ValueError("Aucun chemin possible")
        chemin.append(prochain)
        C = prochain
    chemin.reverse()
    return chemin

