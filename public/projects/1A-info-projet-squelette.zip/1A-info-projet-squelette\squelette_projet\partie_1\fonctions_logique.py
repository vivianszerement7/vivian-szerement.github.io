# cette bibliothèque contient les fonctions logiques du projet
# elle est utilisée par la partie 1 (console) et la partie 2 (FreeCAD)

from types_projet import *
from constantes import *


# genere une grille aleatoire
# @param densite de murs en pourcentage (entier entre 0 et 100)
# @return grille : une liste de liste contenant soit des 0 (mur) soit des 1 (vide)
def generer_grille(densite):
	
	# à faire : écrire le corps de cette fonction

	return grille


	
# verifie si une coordonnée (x ou y) est valide
# valide = entier entre 0 et TAILLE-1
# @param c : la coordonnée (x ou y)
# @return booléen : vrai si valide, faux sinon
def coord_valide(c):

	# à faire : écrire le corps de cette fonction
	pass
	
	
# verifie si une position est valide
# valide = les coordonnées x et y sont valides, et la position n'est pas un mur
# @param x : la coordonnée x de la position
# @param y : la coordonnée y de la position
# @return booléen : vrai si valide, faux sinon
def position_valide(x, y, grille):
	
	# à faire : écrire le corps de cette fonction
	pass
	
	

# calcule les distances dans la grille entre start et target 
# (1ère passe de l'algorithme de Dijsktra adapté aux matrices)
# @param la grille
# @param depart : position de départ (Pos)
# @param arrivée : position d'arrivée (Pos)
# @return chemin_existe : un booléen, vrai si le point d'arrivée a été atteint, 0 sinon
# @return distances : une liste de liste contenant un entier (la distance au point de départ) pour chaque position calculée, ou -1 si la position n'a pas de distance (mur ou position non calculée)
def calcul_distances(grille, depart, arrivee):
	
	# à faire : ecrire le corps de cette fonction
	
	return (chemin_existe, distances)




# renvoie un plus court chemin dans la grille en fonction des distances
# note: un chemin DOIT exister
# (2ème passe de l'algorithme de Dijsktra adapté aux matrices)
# @param distances : la grille des distances, telle que fournie par calcul_distances
# @param depart : position de départ (Pos)
# @param arrivée : position d'arrivée (Pos)
# @return chemin : une liste de positions (Pos) composant le chemin
def calcul_chemin(distances, depart, arrivee):
	
	# à faire : ecrire le corps de cette fonction
	
	return chemin
