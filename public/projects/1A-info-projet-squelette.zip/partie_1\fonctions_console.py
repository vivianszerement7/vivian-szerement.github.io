# cette bibliothèque contient les fonctions du projet liées à la saisie/l'affichage console
# elle est utilisée par la partie 1 du projet

from types_projet import *
from constantes import *
from fonctions_logique import *

# affiche la grille sur la console
# @param grille : la grille (telle que spécifiée par generer_grille)

def afficher_grille(grille):
    for k in range(TAILLE):
        print(k, end="|")
        for j in range(TAILLE - 1):  # de 0 à 8
            if grille[k][j] == 1:
                print(" ", end="|")
            else:
                print("X", end="|")
        # Affiche la dernière colonne (colonne 9) correctement
        if grille[k][9] == 1:
            print(" ", end="|\n")
        else:
            print("X", end="|\n")
    print(" ", end="\n")
    for i in range(TAILLE):
        if i == 0:
            print(" |", end="0|")
        else:
            print(i, end="|")


# affiche la grille, le chemin calculé et les points départ/arrivéé sur la console
# @param grille : la grille (telle que spécifiée par generer_grille)
# @param chemin : chemin calculé
# @param D : point de départ (Pos)
# @param A : point d'arrivée (Pos)
def afficher_grille_chemin(grille, chemin, D, A):
	copie = [[-1 for k in range(10)] for i in range(10)]
	A_x, A_y = A[0], A[1]
	D_x, D_y = D[0], D[1]
	c = len(chemin)
	copie[D_x][D_y] = 0
	copie[A_x][A_y] = len(chemin) +1
	for pos in chemin:
		pos_x, pos_y = pos[0], pos[1]
		copie[pos_x][pos_y] = c
		c -= 1
	for k in range(TAILLE):
		print(k, end="|")
		for j in range(TAILLE-1):
			if grille[k][j] == 0:
				print(" X", end="|")
			elif copie[k][j] != -1 and copie[k][j]<10:
				print(copie[k][j], end=" |")
			elif copie[k][j] != -1:
				print(copie[k][j], end="|")
			else:
				print("  ", end="|")
		if grille[k][9] == 1 and copie[k][9] == -1:
			print("  ", end="|\n")
		elif copie[k][9] >= 10:
			print(copie[k][9], end="|\n")
		elif 0 <= copie[k][9] < 10:
			print(copie[k][9], end=" |\n")
		else:
			print(" X", end="|\n")
	print("", end="\n")
	for i in range(10):
		if i==0:
			print(" |", end="0 |")
		else:
			print(i, end=" |")
	

# permet la saisie d'une position (départ ou arrivée) par l'utilisateur via la console
# redemande une saisie tant que celle-ci n'est pas valide
# @param la grille
# @return la position saisie (Pos)
def saisie_position(grille):
	afficher_grille(grille)
	print("", end="\n")
	print("", end="\n")
	depart_x = input("Départ x :")
	depart_x = int(depart_x)
	depart_y = input("Départ y :")
	depart_y = int(depart_y)
	print("",end="\n")
	arrivee_x = input("Arrivée x :")
	arrivee_x = int(arrivee_x)
	arrivee_y = input("Arrivée y :")
	arrivee_y = int(arrivee_y)
	print("",end="\n")
	depart = (depart_x, depart_y)
	arrivee = (arrivee_x, arrivee_y)
	position = (depart, arrivee)
	return position
