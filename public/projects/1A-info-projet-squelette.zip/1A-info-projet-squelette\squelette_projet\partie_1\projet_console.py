# ce script est le programme principal pour la partie 1 du projet il permet, via la console :

# 1) génération et affichage de la grille
# 2) saisie des points de départ et d'arrivée
# 3) calcul d'un chemin minimal (si existant)
# 4) affichage du résultat (pas de chemin ou chemin affiché dans la grille)

from types_projet import *
from constantes import *
from fonctions_logique import *
from fonctions_console import *

# à faire : écrire le code
