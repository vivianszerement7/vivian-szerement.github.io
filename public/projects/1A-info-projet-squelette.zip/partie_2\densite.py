import sys
if 'fonctions_logique' in sys.modules:
    del sys.modules['fonctions_logique']

from types_projet import *
from constantes import *
from fonctions_logique import *

import FreeCAD as App
import FreeCADGui as Gui
from PySide import QtGui



# TODO : écrire le code
		

# Variables globales pour densité et grille
densite_courante = 50
grille_courante = generer_grille(densite_courante)

class CommandModifierDensite:
    def GetResources(self):
        return {
            'MenuText': 'Modifier densité',
            'ToolTip': 'Modifier la densité de murs et régénérer la grille',
            'Pixmap': ''
        }

    def Activated(self):
        global densite_courante, grille_courante

        densite, ok = QtGui.QInputDialog.getInt(
            None,
            "Densité de murs",
            "Entrez la densité de murs (0 à 100) :",
            densite_courante,
            0,
            100,
            1,
        )
        if not ok:
            return

        densite_courante = densite
        grille_courante = generer_grille(densite_courante)

        App.Console.PrintMessage(f"Densité modifiée à {densite_courante}%.\n")
        App.Console.PrintMessage("Grille régénérée.\n")

    def IsActive(self):
        return True
        
Gui.addCommand('Modifier_Densite', CommandModifierDensite())

mw = Gui.getMainWindow()
tb = mw.findChild(QtGui.QToolBar, "MonToolbar")
if not tb:
    tb = QtGui.QToolBar("MonToolbar")
    tb.setObjectName("MonToolbar")
    mw.addToolBar(tb)
    
    
action_modif = QtGui.QAction("Modifier densité", mw)
action_modif.setToolTip("Modifier la densité des murs et régénérer la grille")
action_modif.triggered.connect(lambda: Gui.runCommand("Modifier_Densite"))
tb.addAction(action_modif)        
