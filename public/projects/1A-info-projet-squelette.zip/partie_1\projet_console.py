# ce script est le programme principal pour la partie 1 du projet il permet, via la console :

# 1) génération et affichage de la grille
# 2) saisie des points de départ et d'arrivée
# 3) calcul d'un chemin minimal (si existant)
# 4) affichage du résultat (pas de chemin ou chemin affiché dans la grille)

from types_projet import *
from constantes import *
from fonctions_logique import *
from fonctions_console import *

# à faire : écrire le code

# 1)

grille = generer_grille(30)
print(grille)
print("")

# 2)

position = saisie_position(grille)
d = position[0]
a = position[1]

# 3)

b, dist = calcul_distances(grille, d, a)

if b == False :
	print("Il n'y a pas de chemin")
else:
	chemin = calcul_chemin(dist, d, a)

# 4)

if b == True:
	afficher_grille_chemin(grille, chemin, d, a)
