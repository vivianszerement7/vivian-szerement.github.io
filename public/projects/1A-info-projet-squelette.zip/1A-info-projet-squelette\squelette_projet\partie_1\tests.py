# ce programme permet de faire des tests au fur et à mesure du développement, il ne fait pas partie du projet final

from constantes import *
from types_projet import *
from fonctions_logique import *
from fonctions_console import *

p = Position(0,0)

print(p.x)
print(p.y)
