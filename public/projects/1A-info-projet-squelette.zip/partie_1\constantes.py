# cette bibliothèque contient les constantes utilisées dans le programme

# la taille de la grille
# cette variable est accessible en tout point du programme, mais sa valeur NE DOIT PAS ETRE MODIFIEE
TAILLE = 10
