# cette bibliothèque contient les fonctions du projet liées à la saisie/l'affichage console
# elle est utilisée par la partie 1 du projet

from types_projet import *
from constantes import *
from fonctions_logique import *

# affiche la grille sur la console
# @param grille : la grille (telle que spécifiée par generer_grille)
def afficher_grille(grille):
	
	# à faire : écrire le corps de cette procédure
	pass

# affiche la grille, le chemin calculé et les points départ/arrivéé sur la console
# @param grille : la grille (telle que spécifiée par generer_grille)
# @param chemin : chemin calculé
# @param D : point de départ (Pos)
# @param A : point d'arrivée (Pos)
def afficher_grille_chemin(grille, chemin, D, A):
	
	# à faire : écrire le corps de cette procédure
	pass
	

# permet la saisie d'une position (départ ou arrivée) par l'utilisateur via la console
# redemande une saisie tant que celle-ci n'est pas valide
# @param la grille
# @return la position saisie (Pos)
def saisie_position(grille):
	
	# à faire : écrire le corps de cette fonction
		
	return position


